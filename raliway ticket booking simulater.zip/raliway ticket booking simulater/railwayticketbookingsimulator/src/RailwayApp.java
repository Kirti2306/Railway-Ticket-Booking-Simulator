import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class RailwayApp {
    private static final BookingService service = new BookingService();
    private static final FileManager files = new FileManager();

    public static void main(String[] args) {
        System.out.println("=== Railway Ticket Booking Simulator ===");
        try {
            files.load(service);
        } catch (Exception e) {
            System.out.println("Could not load saved data: " + e.getMessage());
        }
        if (service.getAllTrains().isEmpty()) seedSampleTrains();

        boolean running = true;
        while (running) {
            try {
                printMenu();
                int choice = InputHelper.readInt("Enter choice: ", 0, 11);
                switch (choice) {
                    case 1:  addTrain(); break;
                    case 2:  viewTrains(); break;
                    case 3:  searchTrains(); break;
                    case 4:  bookTicket(); break;
                    case 5:  cancelTicket(); break;
                    case 6:  viewTicket(); break;
                    case 7:  searchTicketsByPassenger(); break;
                    case 8:  bookingReport(); break;
                    case 9:  waitingListReport(); break;
                    case 10: checkAvailability(); break;
                    case 11: save(); break;
                    case 0:  save(); running = false; System.out.println("Thank you !"); break;
                }
            } catch (RailwayException e) {
                System.out.println("  ERROR: " + e.getMessage());
            } catch (NoSuchElementException e) {      
                save();
                running = false;
            } catch (Exception e) {
                System.out.println("  Unexpected problem: " + e.getMessage());
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n------------- MENU -------------");
        System.out.println(" 1. Add train");
        System.out.println(" 2. View all trains");
        System.out.println(" 3. Search trains by route");
        System.out.println(" 4. Book ticket");
        System.out.println(" 5. Cancel ticket");
        System.out.println(" 6. View ticket by PNR");
        System.out.println(" 7. Search tickets by passenger name");
        System.out.println(" 8. Booking report");
        System.out.println(" 9. Waiting-list report");
        System.out.println("10. Check seat availability");
        System.out.println("11. Save data");
        System.out.println(" 0. Save and exit");
    }

    private static void seedSampleTrains() {
        try {
            service.addTrain(new Train(12001, "Shatabdi Express", "Delhi", "Bhopal", 5));
            service.addTrain(new Train(11401, "Nandigram Express", "Mumbai", "Nagpur", 4));
            service.addTrain(new Train(17064, "Ajanta Express", "Secunderabad", "Manmad", 3));
            System.out.println("(Sample trains created)");
        } catch (InvalidInputException ignored) { }
    }

    // ---------- Feature methods ----------
    private static void addTrain() throws RailwayException {
        int no = InputHelper.readInt("Train number (1-99999): ", 1, 99999);
        String name = InputHelper.readText("Train name: ");
        String src = InputHelper.readText("Source station: ");
        String dst = InputHelper.readText("Destination station: ");
        if (src.equalsIgnoreCase(dst)) throw new InvalidInputException("Source and destination must be different.");
        int seats = InputHelper.readInt("Total seats (1-500): ", 1, 500);
        service.addTrain(new Train(no, name, src, dst, seats));
        System.out.println("Train added.");
    }

    private static void viewTrains() {
        printTrains(service.getAllTrains());
    }

    private static void printTrains(List<Train> list) {
        if (list.isEmpty()) { System.out.println("No trains found."); return; }
        System.out.printf("%-6s %-22s %-32s %s%n", "No.", "Name", "Route", "Seats");
        list.forEach(System.out::println);
    }

    private static void searchTrains() {
        String key = InputHelper.readText("Enter source or destination (partial ok): ").toLowerCase();
        Predicate<Train> onRoute = t -> t.getSource().toLowerCase().contains(key)
                                     || t.getDestination().toLowerCase().contains(key);
        printTrains(service.searchTrains(onRoute));
    }

    private static void bookTicket() throws RailwayException {
        printTrains(service.getAllTrains());
        int trainNo = InputHelper.readInt("Train number: ", 1, 99999);
        Train train = service.getTrain(trainNo);
        LocalDate date = InputHelper.readDate("Travel date (dd-MM-yyyy): ");
        System.out.println("Seats available: " + service.availableSeats(train, date)
                + " | Waiting: " + service.waitingList(train, date).size() + "/" + BookingService.MAX_WAITING);

        String name = InputHelper.readName("Passenger name: ");
        int age = InputHelper.readInt("Age (1-120): ", 1, 120);
        String contact = InputHelper.readContact("Contact (10 digits): ");
        boolean wl = InputHelper.readYesNo("Join waiting list if train is full?");

        Ticket t = service.bookTicket(new Passenger(name, age, contact), trainNo, date, wl);
        System.out.println("\nBooking successful!\n" + t);
    }

    private static void cancelTicket() throws RailwayException {
        int pnr = InputHelper.readInt("PNR to cancel: ", 1, Integer.MAX_VALUE);
        Ticket t = service.findTicket(pnr);
        System.out.println(t);
        if (!InputHelper.readYesNo("Cancel this ticket?")) { System.out.println("Cancellation aborted."); return; }
        Ticket promoted = service.cancelTicket(pnr);
        System.out.println("Ticket " + pnr + " cancelled.");
        if (promoted != null)
            System.out.println("Waiting-list passenger promoted:\n" + promoted);
    }

    private static void viewTicket() throws RailwayException {
        int pnr = InputHelper.readInt("PNR: ", 1, Integer.MAX_VALUE);
        Ticket t = service.findTicket(pnr);
        System.out.println(t);
        System.out.println("Passenger: " + t.getPassenger() + " | Route: " + t.getTrain().getRoute());
    }

    private static void searchTicketsByPassenger() {
        String key = InputHelper.readText("Passenger name (partial ok): ").toLowerCase();
        List<Ticket> found = service.searchTickets(t -> t.getPassenger().getName().toLowerCase().contains(key));
        if (found.isEmpty()) System.out.println("No tickets found.");
        else found.forEach(System.out::println);
    }

    private static void bookingReport() {
        List<Ticket> all = service.getTickets();
        if (all.isEmpty()) { System.out.println("No bookings yet."); return; }
        System.out.println("\n--- All bookings (sorted by date, train, PNR) ---");
        all.stream()
           .sorted(Comparator.comparing(Ticket::getTravelDate)
                             .thenComparing(t -> t.getTrain().getNumber())
                             .thenComparingInt(Ticket::getPnr))
           .forEach(System.out::println);

        Map<Integer, Long> perTrain = all.stream()
                .collect(Collectors.groupingBy(t -> t.getTrain().getNumber(), Collectors.counting()));
        System.out.println("\n--- Tickets per train ---");
        perTrain.forEach((no, count) -> System.out.println("Train " + no + ": " + count + " ticket(s)"));
        long confirmed = all.stream().filter(Ticket::isConfirmed).count();
        System.out.println("Confirmed: " + confirmed + " | Waiting: " + (all.size() - confirmed));
    }

    private static void waitingListReport() {
        List<Ticket> wl = service.searchTickets(t -> !t.isConfirmed());
        if (wl.isEmpty()) { System.out.println("Waiting list is empty."); return; }
        System.out.println("\n--- Waiting list ---");
        wl.stream()
          .sorted(Comparator.comparing((Ticket t) -> t.getTrain().getNumber())
                            .thenComparing(Ticket::getTravelDate)
                            .thenComparingInt(Ticket::getNumber))
          .forEach(System.out::println);
    }

    private static void checkAvailability() throws RailwayException {
        Train train = service.getTrain(InputHelper.readInt("Train number: ", 1, 99999));
        LocalDate date = InputHelper.readDate("Travel date (dd-MM-yyyy): ");
        System.out.println(train.getName() + " (" + train.getRoute() + ")");
        System.out.println("Total: " + train.getTotalSeats() + " | Booked: " + service.bookedSeats(train, date)
                + " | Available: " + service.availableSeats(train, date)
                + " | Waiting: " + service.waitingList(train, date).size());
    }

    private static void save() {
        try {
            files.save(service);
            System.out.println("Data saved.");
        } catch (Exception e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }
}
