import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Reads and validates console input. Keeps asking until the value is valid. */
public class InputHelper {
    public static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final Scanner SC = new Scanner(System.in);

    private static String readLine(String prompt) {
        System.out.print(prompt);
        if (!SC.hasNextLine()) throw new NoSuchElementException("Input closed");
        return SC.nextLine().trim();
    }

    public static int readInt(String prompt, int min, int max) {
        while (true) {
            String s = readLine(prompt);
            try {
                int v = Integer.parseInt(s);
                if (v >= min && v <= max) return v;
                System.out.println("  Enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("  '" + s + "' is not a valid number.");
            }
        }
    }

    public static String readText(String prompt) {
        while (true) {
            String s = readLine(prompt);
            if (s.isEmpty()) System.out.println("  This field cannot be empty.");
            else if (s.contains(",")) System.out.println("  Commas are not allowed (CSV storage).");
            else return s;
        }
    }

    public static String readName(String prompt) {
        while (true) {
            String s = readLine(prompt);
            if (s.matches("[A-Za-z][A-Za-z .]*")) return s;
            System.out.println("  Name must contain only letters and spaces.");
        }
    }

    public static String readContact(String prompt) {
        while (true) {
            String s = readLine(prompt);
            if (s.matches("\\d{10}")) return s;
            System.out.println("  Contact must be exactly 10 digits.");
        }
    }

    public static LocalDate readDate(String prompt) {
        while (true) {
            String s = readLine(prompt);
            try {
                LocalDate d = LocalDate.parse(s, DATE_FMT);
                if (d.isBefore(LocalDate.now())) System.out.println("  Date cannot be in the past.");
                else return d;
            } catch (DateTimeParseException e) {
                System.out.println("  Invalid date. Use dd-MM-yyyy (e.g. 25-12-2026).");
            }
        }
    }

    public static boolean readYesNo(String prompt) {
        while (true) {
            String s = readLine(prompt + " (y/n): ").toLowerCase();
            if (s.equals("y") || s.equals("yes")) return true;
            if (s.equals("n") || s.equals("no")) return false;
            System.out.println("  Please type y or n.");
        }
    }
}
