import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;

/** Saves and loads trains and tickets as CSV text files inside the "data" folder. */
public class FileManager {
    private static final Path DIR = Paths.get("data");
    private static final Path TRAIN_FILE = DIR.resolve("trains.csv");
    private static final Path TICKET_FILE = DIR.resolve("tickets.csv");

    public void save(BookingService service) throws IOException {
        Files.createDirectories(DIR);

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(TRAIN_FILE.toFile())))) {
            out.println("number,name,source,destination,totalSeats");
            service.getAllTrains().forEach(t -> out.println(
                    t.getNumber() + "," + t.getName() + "," + t.getSource() + "," + t.getDestination() + "," + t.getTotalSeats()));
        }

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(TICKET_FILE.toFile())))) {
            out.println("pnr,trainNumber,travelDate,name,age,contact,type,number");
            service.getTickets().forEach(k -> out.println(
                    k.getPnr() + "," + k.getTrain().getNumber() + "," + k.getTravelDate() + "," +
                    k.getPassenger().getName() + "," + k.getPassenger().getAge() + "," +
                    k.getPassenger().getContact() + "," + k.getTypeCode() + "," + k.getNumber()));
        }
    }

    public void load(BookingService service) throws IOException {
        if (Files.exists(TRAIN_FILE)) {
            List<String> lines = Files.readAllLines(TRAIN_FILE);
            for (int i = 1; i < lines.size(); i++) {
                if (lines.get(i).isBlank()) continue;
                try {
                    String[] f = lines.get(i).split(",", -1);
                    service.addTrain(new Train(Integer.parseInt(f[0]), f[1], f[2], f[3], Integer.parseInt(f[4])));
                } catch (Exception e) {
                    System.out.println("Skipping bad train record (line " + (i + 1) + "): " + e.getMessage());
                }
            }
        }
        if (Files.exists(TICKET_FILE)) {
            List<String> lines = Files.readAllLines(TICKET_FILE);
            for (int i = 1; i < lines.size(); i++) {
                if (lines.get(i).isBlank()) continue;
                try {
                    String[] f = lines.get(i).split(",", -1);
                    int pnr = Integer.parseInt(f[0]);
                    Train train = service.getTrain(Integer.parseInt(f[1]));
                    LocalDate date = LocalDate.parse(f[2]);
                    Passenger p = new Passenger(f[3], Integer.parseInt(f[4]), f[5]);
                    int num = Integer.parseInt(f[7]);
                    Ticket t = f[6].equals("CNF") ? new ConfirmedTicket(pnr, p, train, date, num)
                                                  : new WaitingTicket(pnr, p, train, date, num);
                    service.restoreTicket(t);
                } catch (Exception e) {
                    System.out.println("Skipping bad ticket record (line " + (i + 1) + "): " + e.getMessage());
                }
            }
        }
    }
}
