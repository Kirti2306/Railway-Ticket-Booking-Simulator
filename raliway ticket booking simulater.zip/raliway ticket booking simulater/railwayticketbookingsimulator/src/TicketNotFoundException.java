public class TicketNotFoundException extends RailwayException {
    public TicketNotFoundException(int pnr) { super("No ticket found with PNR " + pnr + "."); }
}
