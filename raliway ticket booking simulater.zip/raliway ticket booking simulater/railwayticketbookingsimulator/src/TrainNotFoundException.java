public class TrainNotFoundException extends RailwayException {
    public TrainNotFoundException(int number) { super("No train found with number " + number + "."); }
}
