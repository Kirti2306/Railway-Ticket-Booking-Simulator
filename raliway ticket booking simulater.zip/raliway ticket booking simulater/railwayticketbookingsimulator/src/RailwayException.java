public class RailwayException extends Exception {
    public RailwayException(String message) { super(message); }
}
