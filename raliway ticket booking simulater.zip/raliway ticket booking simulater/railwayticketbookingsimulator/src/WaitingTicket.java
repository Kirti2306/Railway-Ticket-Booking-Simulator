import java.time.LocalDate;

public class WaitingTicket extends Ticket {
    private int waitingNumber;

    public WaitingTicket(int pnr, Passenger p, Train t, LocalDate d, int waitingNumber) {
        super(pnr, p, t, d);
        this.waitingNumber = waitingNumber;
    }

    public int getWaitingNumber() { return waitingNumber; }
    public void setWaitingNumber(int waitingNumber) { this.waitingNumber = waitingNumber; }
    @Override public boolean isConfirmed() { return false; }
    @Override public String getTypeCode() { return "WL"; }
    @Override public int getNumber() { return waitingNumber; }
    @Override public String getStatusText() { return "WAITING    WL " + waitingNumber; }
}
