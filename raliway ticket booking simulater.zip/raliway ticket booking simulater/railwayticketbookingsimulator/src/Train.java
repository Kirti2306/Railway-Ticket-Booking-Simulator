public class Train {
    private int number;
    private String name;
    private String source;
    private String destination;
    private int totalSeats;

    public Train(int number, String name, String source, String destination, int totalSeats) {
        this.number = number;
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.totalSeats = totalSeats;
    }

    public int getNumber() { return number; }
    public String getName() { return name; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public int getTotalSeats() { return totalSeats; }
    public String getRoute() { return source + " -> " + destination; }

    public void setNumber(int number) { this.number = number; }
    public void setName(String name) { this.name = name; }
    public void setSource(String source) { this.source = source; }
    public void setDestination(String destination) { this.destination = destination; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }

    @Override
    public String toString() {
        return String.format("%-6d %-22s %-32s Seats: %d", number, name, getRoute(), totalSeats);
    }
}



