import java.time.LocalDate;

public class ConfirmedTicket extends Ticket {
    private final int seatNumber;

    public ConfirmedTicket(int pnr, Passenger p, Train t, LocalDate d, int seatNumber) {
        super(pnr, p, t, d);
        this.seatNumber = seatNumber;
    }

    public int getSeatNumber() { return seatNumber; }
    @Override public boolean isConfirmed() { return true; }
    @Override public String getTypeCode() { return "CNF"; }
    @Override public int getNumber() { return seatNumber; }
    @Override public String getStatusText() { return "CONFIRMED  Seat " + seatNumber; }
}
