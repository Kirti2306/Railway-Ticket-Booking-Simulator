import java.time.LocalDate;

public abstract class Ticket {
    private final int pnr;
    private final Passenger passenger;
    private final Train train;
    private final LocalDate travelDate;

    protected Ticket(int pnr, Passenger passenger, Train train, LocalDate travelDate) {
        this.pnr = pnr;
        this.passenger = passenger;
        this.train = train;
        this.travelDate = travelDate;
    }

    public int getPnr() { return pnr; }
    public Passenger getPassenger() { return passenger; }
    public Train getTrain() { return train; }
    public LocalDate getTravelDate() { return travelDate; }

    public abstract boolean isConfirmed();
    public abstract String getTypeCode();     // CNF or WL (used in the CSV file)
    public abstract int getNumber();          // seat number or waiting-list number
    public abstract String getStatusText();   // text for the user

    @Override
    public String toString() {
        return String.format("PNR %-5d | %-15s | %-5d %-18s | %s | %s",
                pnr, passenger.getName(), train.getNumber(), train.getName(),
                travelDate.format(InputHelper.DATE_FMT), getStatusText());
    }
}
