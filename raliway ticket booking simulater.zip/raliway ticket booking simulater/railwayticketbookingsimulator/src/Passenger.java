public class Passenger {
    private String name;
    private int age;
    private String contact;

    public Passenger(String name, int age, String contact) {
        this.name = name;
        this.age = age;
        this.contact = contact;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getContact() { return contact; }

    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setContact(String contact) { this.contact = contact; }

    @Override
    public String toString() {
        return name + " (Age " + age + ", Ph " + contact + ")";
    }
}
