public class InvalidInputException extends RailwayException {
    public InvalidInputException(String message) { super(message); }
}
