public class TrainFullException extends RailwayException {
    public TrainFullException(String message) { super(message); }
}
