import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/** Core business logic: trains, booking, waiting list, cancellation and promotion. */
public class BookingService {
    public static final int MAX_WAITING = 5;   // max waiting-list size per train per date

    private final Map<Integer, Train> trains = new HashMap<>();
    private final List<Ticket> tickets = new ArrayList<>();
    private int nextPnr = 1001;

    // ---------- Trains ----------
    public void addTrain(Train train) throws InvalidInputException {
        if (trains.containsKey(train.getNumber()))
            throw new InvalidInputException("Train " + train.getNumber() + " already exists.");
        trains.put(train.getNumber(), train);
    }

    public Train getTrain(int number) throws TrainNotFoundException {
        Train train = trains.get(number);
        if (train == null) throw new TrainNotFoundException(number);
        return train;
    }

    public List<Train> getAllTrains() {
        return trains.values().stream()
                .sorted(Comparator.comparingInt(Train::getNumber))
                .collect(Collectors.toList());
    }

    public List<Train> searchTrains(Predicate<Train> filter) {
        return getAllTrains().stream().filter(filter).collect(Collectors.toList());
    }

    // ---------- Seats ----------
    public int bookedSeats(Train train, LocalDate date) {
        return (int) tickets.stream()
                .filter(x -> x.isConfirmed() && sameJourney(x, train, date)).count();
    }

    public int availableSeats(Train train, LocalDate date) {
        return train.getTotalSeats() - bookedSeats(train, date);
    }

    public List<WaitingTicket> waitingList(Train train, LocalDate date) {
        return tickets.stream()
                .filter(x -> !x.isConfirmed() && sameJourney(x, train, date))
                .map(x -> (WaitingTicket) x)
                .sorted(Comparator.comparingInt(WaitingTicket::getWaitingNumber))
                .collect(Collectors.toList());
    }

    private boolean sameJourney(Ticket x, Train train, LocalDate date) {
        return x.getTrain().getNumber() == train.getNumber() && x.getTravelDate().equals(date);
    }

    private int firstFreeSeat(Train train, LocalDate date) {
        boolean[] used = new boolean[train.getTotalSeats() + 1];
        tickets.stream()
                .filter(x -> x.isConfirmed() && sameJourney(x, train, date))
                .forEach(x -> used[x.getNumber()] = true);
        for (int s = 1; s <= train.getTotalSeats(); s++) if (!used[s]) return s;
        return -1;
    }

    // ---------- Booking ----------
    public Ticket bookTicket(Passenger passenger, int trainNumber, LocalDate date, boolean allowWaiting)
            throws RailwayException {
        Train train = getTrain(trainNumber);
        int seat = firstFreeSeat(train, date);
        Ticket ticket;
        if (seat > 0) {
            ticket = new ConfirmedTicket(nextPnr++, passenger, train, date, seat);
        } else if (!allowWaiting) {
            throw new TrainFullException("Train " + trainNumber + " is full on this date and waiting list was not chosen.");
        } else {
            int size = waitingList(train, date).size();
            if (size >= MAX_WAITING)
                throw new TrainFullException("Train is full and the waiting list is also full (max " + MAX_WAITING + ").");
            ticket = new WaitingTicket(nextPnr++, passenger, train, date, size + 1);
        }
        tickets.add(ticket);
        return ticket;
    }

    // ---------- Cancellation ----------
    public Ticket findTicket(int pnr) throws TicketNotFoundException {
        return tickets.stream().filter(x -> x.getPnr() == pnr).findFirst()
                .orElseThrow(() -> new TicketNotFoundException(pnr));
    }

    /** Cancels a ticket. Returns the promoted waiting-list ticket, or null if nobody was promoted. */
    public Ticket cancelTicket(int pnr) throws TicketNotFoundException {
        Ticket cancelled = findTicket(pnr);
        tickets.remove(cancelled);
        Train train = cancelled.getTrain();
        LocalDate date = cancelled.getTravelDate();
        Ticket promoted = null;

        if (cancelled.isConfirmed()) {
            List<WaitingTicket> wl = waitingList(train, date);
            if (!wl.isEmpty()) {
                WaitingTicket first = wl.get(0);
                promoted = new ConfirmedTicket(first.getPnr(), first.getPassenger(), train, date, cancelled.getNumber());
                tickets.set(tickets.indexOf(first), promoted);
            }
        }
        renumberWaitingList(train, date);
        return promoted;
    }

    private void renumberWaitingList(Train train, LocalDate date) {
        List<WaitingTicket> wl = waitingList(train, date);
        for (int i = 0; i < wl.size(); i++) wl.get(i).setWaitingNumber(i + 1);
    }

    // ---------- Tickets ----------
    public List<Ticket> getTickets() { return new ArrayList<>(tickets); }

    public List<Ticket> searchTickets(Predicate<Ticket> filter) {
        return tickets.stream().filter(filter).collect(Collectors.toList());
    }

    /** Used when loading from file: keeps the stored PNR. */
    public void restoreTicket(Ticket ticket) {
        tickets.add(ticket);
        nextPnr = Math.max(nextPnr, ticket.getPnr() + 1);
    }
}
